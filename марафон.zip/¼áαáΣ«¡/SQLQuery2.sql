use g464_Iln_Ala
go
insert into Inventory values ('Order', 0,0,0,0,0,0);
go
insert into Inventory values ('Necessary', 0,0,0,0,0,0);
go
insert into Inventory values ('Balance', 300,300,300,300,300,300);
go


SELECT        dbo.Event.StartDateTime, dbo.RegistrationEvent.BibNumber, STUFF(CONVERT(VARCHAR,DATEADD(SECOND,dbo.RegistrationEvent.RaceTime,0),8),1,2,dbo.RegistrationEvent.RaceTime/(60*60)), dbo.Marathon.CityName, dbo.Marathon.YearHeld, dbo.Event.EventName
FROM            dbo.Runner INNER JOIN
                         dbo.Registration ON dbo.Runner.RunnerId = dbo.Registration.RunnerId INNER JOIN
                         dbo.RegistrationEvent ON dbo.Registration.RegistrationId = dbo.RegistrationEvent.RegistrationId INNER JOIN
                         dbo.Event INNER JOIN
                         dbo.Marathon ON dbo.Event.MarathonId = dbo.Marathon.MarathonId ON dbo.RegistrationEvent.EventId = dbo.Event.EventId
WHERE        (dbo.Runner.Email = 'g.hurt@hotmail.com')
go

select count(VolunteerId) as count from Volunteer

insert into Sostav values ('Number', 2,1,1);
go
insert into Sostav values ('Bracelet', 1,1,1);
go
insert into Sostav values ('Hut', 0,1,1);
go
insert into Sostav values ('Water', 0,1,1);
go
insert into Sostav values ('TShirt', 0,0,1);
go
insert into Sostav values ('Booklet', 0,0,1);
go