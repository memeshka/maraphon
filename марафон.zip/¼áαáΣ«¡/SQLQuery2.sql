insert into Inventory values ('Order', 0,0,0,0,0,0);
go
insert into Inventory values ('Necessary', 0,0,0,0,0,0);
go
insert into Inventory values ('Balance', 300,300,300,300,300,300);
go