﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace марафон
{
    class Class1
    {
        public static DateTime data { get; set; }
        public static string textBox1 { get; set; }
        public static string textBox7 { get; set; }
        public static string textBox6 { get; set; }
        public static string textBox5 { get; set; }
        public static string comboBox1 { get; set; }
        public static string comboBox2 { get; set; }



        public static string Pictures { get; set; }

        public static string Login { get; set; }

        public static string Kit1 { get; set; }
    }
}
