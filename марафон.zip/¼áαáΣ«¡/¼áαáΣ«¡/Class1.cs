﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace марафон
{
    class Class1
    {
        internal static string SostavAA;
        internal static string SostavB;
        internal static string SostavBB;
        internal static string SostavBBB;
        internal static string SostavBBBB;
        internal static string SostavC;
        internal static string SostavCC;
        internal static string SostavCCC;
        internal static string SostavCCCC;
        internal static string SostavССССС;
        internal static string SostavСССССС;


        public static DateTime data { get; set; }
        public static string textBox1 { get; set; }
        public static string textBox7 { get; set; }
        public static string textBox6 { get; set; }
        public static string textBox5 { get; set; }
        public static string comboBox1 { get; set; }
        public static string comboBox2 { get; set; }



        public static string Pictures { get; set; }

        public static string Login { get; set; }

        public static string Kit1 { get; set; }

        public static string KitC { get; set; }

        public static string KitCC { get; set; }

        public static string KitA { get; set; }

        public static string KitAA { get; set; }

        public static string SostavA { get; set; }
    }
}
