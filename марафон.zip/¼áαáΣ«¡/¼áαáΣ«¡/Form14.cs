﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace марафон
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "g464_Iln_AlaDataSet3.Charity". При необходимости она может быть перемещена или удалена.
            this.charityTableAdapter.Fill(this.g464_Iln_AlaDataSet3.Charity);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "g464_Iln_AlaDataSet2.Sponsorship". При необходимости она может быть перемещена или удалена.
            this.sponsorshipTableAdapter.Fill(this.g464_Iln_AlaDataSet2.Sponsorship);

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan t = Program.start - DateTime.Now;
            label10.Text = t.Days.ToString() + " days, " +
                t.Hours.ToString() + " hours, " +
                t.Minutes.ToString() + " minutes";
        }

        public void button1_Click(object sender, EventArgs e)
        {
            int id = 0;

            //  string conn = "Data Source=127.0.0.1;Initial Catalog=g464_Iln_Ala;User ID=student;Password=student";
            string conn = "Data Source=WIN-D0D1L0QJR2B;Initial Catalog=g464_Iln_Ala;Integrated Security=True";
            SqlConnection con = new SqlConnection(conn);

            con.Open();
            string str = "INSERT INTO [user] ([Email],[Password],[FirstName],[LastName],[RoleId], [Pictures]) VALUES ('" + Class1.textBox1 + "','" + Class1.textBox7 + "','" + Class1.textBox6 + "','" + Class1.textBox5 + "','R' , '" + Class1.Pictures + "')";
            string str2 = "INSERT INTO [Runner] ([Email],[Gender],[DateOfBirth],[CountryCode]) VALUES ('" + Class1.textBox1 + "','" + Class1.comboBox1 + "','" + Class1.data + "','" + Class1.comboBox2 + "')";
            SqlCommand cmd2 = new SqlCommand(str, con);
            cmd2.ExecuteNonQuery();
            SqlCommand cmd3 = new SqlCommand(str2, con);
            cmd3.ExecuteNonQuery();

            string str4 = "SELECT [RunnerID] FROM [dbo].[Runner] WHERE [Email]='" + Class1.textBox1 + "'";
            SqlCommand cmd = new SqlCommand(str4, con);
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read() == true)
            {
                id = rdr.GetInt32(0);
            }
            rdr.Close();

            string str3 = "INSERT INTO [Registration] ([RunnerId],[RegistrationDateTime],[RaceKitOptionId],[RegistrationStatusId],[Cost],[CharityId],[SponsorshipTarget]) VALUES ('" + id + "','" + DateTime.Today + "','" + Class1.Kit1 + "','" + "1" + "','" + label9.Text + "','" + comboBox2.SelectedValue + "','" + textBox1.Text + "')";
            SqlCommand cmd4 = new SqlCommand(str3, con);
            cmd4.ExecuteNonQuery();

            SqlCommand cmd201 = new SqlCommand(Class1.KitA, con);
            cmd201.ExecuteNonQuery();

            SqlCommand cmd202 = new SqlCommand(Class1.KitAA, con);
            cmd202.ExecuteNonQuery();


            con.Close();

            this.Close();
            Form16 yyy = new Form16();
            yyy.Show();

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) + 145);
            }
            else
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) - 145);
            }
        }
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) + 75);
            }
            else
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) - 75);
            }
        }
        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) + 20);
            }
            else 
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) - 20);
            }
        }



        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) + 0);
                Class1.Kit1 = "A";
                Class1.KitA = "UPDATE [Inventory]  SET [Номер бегуна]=[Номер бегуна]+1,[RFID браслет]=[RFID браслет]+1 WHERE([Инвентарь]='Neobhodimo')";
                Class1.KitAA = "UPDATE[Inventory]  SET [Номер бегуна] =[Номер бегуна] - 1,[RFID браслет]=[RFID браслет]-1 WHERE([Инвентарь]= 'Ostatok')";
                Class1.SostavA = "UPDATE [Sostav] SET A=A+1 WHERE  [Состав]='Браслет'";
                Class1.SostavAA = "UPDATE [Sostav] SET A=A+1 WHERE  [Состав]='Номер бегуна'";

            }
            else
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) - 0);
            }
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) + 20);
                Class1.Kit1 = "B";
                Class1.Kit1 = "B";
                Class1.KitA = "UPDATE [Inventory]  SET [Номер бегуна]=[Номер бегуна]+1,[RFID браслет]=[RFID браслет]+1,[Бейсболка]=[Бейсболка]+1,[Бутылка воды]=[Бутылка воды]+1 WHERE([Инвентарь]='Neobhodimo')";
                Class1.KitAA = "UPDATE[Inventory]  SET [Номер бегуна] =[Номер бегуна] - 1,[RFID браслет]=[RFID браслет]-1,[Бейсболка]=[Бейсболка]-1,[Бутылка воды]=[Бутылка воды]-1 WHERE([Инвентарь]= 'Ostatok')";
                Class1.SostavB = " UPDATE[Sostav] SET  B = B + 1 WHERE[Состав] = 'Номер бегуна'";
                Class1.SostavBB = "UPDATE[Sostav] SET  B = B + 1 WHERE[Состав] = 'Браслет'";
                Class1.SostavBBB = "UPDATE[Sostav] SET B = B + 1 WHERE[Состав] = 'Бейсболка'";
                Class1.SostavBBBB = "UPDATE[Sostav] SET B = B + 1 WHERE[Состав] = 'Вода'";

            }
            else
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) - 20);
            }
        }
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) + 45);
                Class1.Kit1 = "C";
                Class1.KitA = "UPDATE [Inventory]  SET [Номер бегуна]=[Номер бегуна]+1,[RFID браслет]=[RFID браслет]+1,[Бейсболка]=[Бейсболка]+1,[Бутылка воды]=[Бутылка воды]+1,[Футболка]=[Футболка]+1,[Сувенирный буклет]=[Сувенирный буклет]+1 WHERE([Инвентарь]='Neobhodimo')";
                Class1.KitAA = "UPDATE[Inventory]  SET[Номер бегуна] =[Номер бегуна] - 1,[RFID браслет]=[RFID браслет]-1,[Бейсболка]=[Бейсболка]-1,[Бутылка воды]=[Бутылка воды]-1,[Футболка]=[Футболка]-1,[Сувенирный буклет]=[Сувенирный буклет]-1 WHERE([Инвентарь]= 'Ostatok')";
                Class1.SostavC = " UPDATE[Sostav] SET  C = C + 1 WHERE[Состав] = 'Номер бегуна'";
                Class1.SostavCC = "UPDATE[Sostav] SET  C = C + 1 WHERE[Состав] = 'Браслет'";
                Class1.SostavCCC = "UPDATE[Sostav] SET C = C + 1 WHERE[Состав] = 'Бейсболка'";
                Class1.SostavCCCC = "UPDATE[Sostav] SET C = C + 1 WHERE[Состав] = 'Вода'";
                Class1.SostavССССС = "UPDATE[Sostav] SET C = C + 1 WHERE[Состав] = 'Футболка'";
                Class1.SostavСССССС = "UPDATE[Sostav] SET C = C + 1 WHERE[Состав] = 'Буклет'";

            }
            else
            {
                label9.Text = Convert.ToString(Convert.ToInt32(label9.Text) - 45);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form8 yyy = new Form8();
            yyy.Show();
        }

       

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 yyy = new Form1();
            yyy.Show();
        }

        private void label9_Click(object sender, EventArgs e)
        {
           
        }
    }
}
