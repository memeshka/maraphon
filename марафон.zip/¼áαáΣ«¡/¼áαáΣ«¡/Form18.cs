﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace марафон
{
    public partial class Form18 : Form
    {
        public Form18()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form18_Load(object sender, EventArgs e)
        {
            DateTime GodRojd = DateTime.Today;


            //  string conn = "Data Source=127.0.0.1;Initial Catalog=g464_Iln_Ala;User ID=student;Password=student";
            string conn = "Data Source=WIN-D0D1L0QJR2B;Initial Catalog=g464_Iln_Ala;Integrated Security=True";
            // string str = "select [Email],[Password],[RoleId] FROM [User] WHERE [Email]='" + textBox1.Text + "' AND [Password]='" + textBox2.Text + "'";
            string str = "SELECT  [Gender],[DateOfBirth] FROM [g464_Iln_Ala].[dbo].[Runner] WHERE [Email] = '" + Class1.Login + "'";
            SqlConnection con = new SqlConnection(conn);
            con.Open();
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read() == true)
            {
                label3.Text = rdr.GetString(0);
                GodRojd = rdr.GetDateTime(1);
            }
            rdr.Close();
            DateTime now = DateTime.Today;
            try
            {
                int age = now.Year - GodRojd.Year;
                if (now < GodRojd.AddYears(age)) age--;
                label4.Text = Convert.ToString(age);
                if (age < 18) label6.Text = "до 18";
                else if (age >= 18 && age <= 29) label6.Text = "От 18 до 29";
                else if (age >= 30 && age <= 39) label6.Text = "От 30 до 39";
                else if (age >= 40 && age <= 55) label6.Text = "От 40 до 55";
                else if (age >= 56 && age <= 70) label6.Text = "От 56 до 70";
                else if (age < 70) label6.Text = "более 70";

            }
            catch
            {
                MessageBox.Show("MEOW");
            }
        }
    }
}
