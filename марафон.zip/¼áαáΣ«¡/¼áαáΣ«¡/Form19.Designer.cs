﻿namespace марафон
{
    partial class Form19
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.aDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.neobhodimoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.neobxBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.g464_Iln_AlaDataSet9 = new марафон.g464_Iln_AlaDataSet9();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.expr1DataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sumBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.g464_Iln_AlaDataSet8 = new марафон.g464_Iln_AlaDataSet8();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.raceKitOptionIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.expr1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numABindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.g464_Iln_AlaDataSet7 = new марафон.g464_Iln_AlaDataSet7();
            this.button1 = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.numATableAdapter = new марафон.g464_Iln_AlaDataSet7TableAdapters.numATableAdapter();
            this.sumTableAdapter = new марафон.g464_Iln_AlaDataSet8TableAdapters.sumTableAdapter();
            this.neobxTableAdapter = new марафон.g464_Iln_AlaDataSet9TableAdapters.NeobxTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.neobxBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_Iln_AlaDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_Iln_AlaDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numABindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_Iln_AlaDataSet7)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.aDataGridViewTextBoxColumn,
            this.bDataGridViewTextBoxColumn,
            this.cDataGridViewTextBoxColumn,
            this.neobhodimoDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.neobxBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(36, 247);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(445, 200);
            this.dataGridView3.TabIndex = 66;
            // 
            // aDataGridViewTextBoxColumn
            // 
            this.aDataGridViewTextBoxColumn.DataPropertyName = "A";
            this.aDataGridViewTextBoxColumn.HeaderText = "A";
            this.aDataGridViewTextBoxColumn.Name = "aDataGridViewTextBoxColumn";
            // 
            // bDataGridViewTextBoxColumn
            // 
            this.bDataGridViewTextBoxColumn.DataPropertyName = "B";
            this.bDataGridViewTextBoxColumn.HeaderText = "B";
            this.bDataGridViewTextBoxColumn.Name = "bDataGridViewTextBoxColumn";
            // 
            // cDataGridViewTextBoxColumn
            // 
            this.cDataGridViewTextBoxColumn.DataPropertyName = "C";
            this.cDataGridViewTextBoxColumn.HeaderText = "C";
            this.cDataGridViewTextBoxColumn.Name = "cDataGridViewTextBoxColumn";
            // 
            // neobhodimoDataGridViewTextBoxColumn
            // 
            this.neobhodimoDataGridViewTextBoxColumn.DataPropertyName = "Neobhodimo";
            this.neobhodimoDataGridViewTextBoxColumn.HeaderText = "Neobhodimo";
            this.neobhodimoDataGridViewTextBoxColumn.Name = "neobhodimoDataGridViewTextBoxColumn";
            this.neobhodimoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // neobxBindingSource
            // 
            this.neobxBindingSource.DataMember = "Neobx";
            this.neobxBindingSource.DataSource = this.g464_Iln_AlaDataSet9;
            // 
            // g464_Iln_AlaDataSet9
            // 
            this.g464_Iln_AlaDataSet9.DataSetName = "g464_Iln_AlaDataSet9";
            this.g464_Iln_AlaDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(225, 453);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 65;
            this.button2.Text = "Далее";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.expr1DataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.sumBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(300, 64);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(145, 147);
            this.dataGridView2.TabIndex = 64;
            // 
            // expr1DataGridViewTextBoxColumn1
            // 
            this.expr1DataGridViewTextBoxColumn1.DataPropertyName = "Expr1";
            this.expr1DataGridViewTextBoxColumn1.HeaderText = "Необходимо";
            this.expr1DataGridViewTextBoxColumn1.Name = "expr1DataGridViewTextBoxColumn1";
            // 
            // sumBindingSource
            // 
            this.sumBindingSource.DataMember = "sum";
            this.sumBindingSource.DataSource = this.g464_Iln_AlaDataSet8;
            // 
            // g464_Iln_AlaDataSet8
            // 
            this.g464_Iln_AlaDataSet8.DataSetName = "g464_Iln_AlaDataSet8";
            this.g464_Iln_AlaDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonShadow;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.raceKitOptionIdDataGridViewTextBoxColumn,
            this.expr1DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.numABindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(56, 64);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(244, 147);
            this.dataGridView1.TabIndex = 63;
            // 
            // raceKitOptionIdDataGridViewTextBoxColumn
            // 
            this.raceKitOptionIdDataGridViewTextBoxColumn.DataPropertyName = "RaceKitOptionId";
            this.raceKitOptionIdDataGridViewTextBoxColumn.HeaderText = "Комплект";
            this.raceKitOptionIdDataGridViewTextBoxColumn.Name = "raceKitOptionIdDataGridViewTextBoxColumn";
            // 
            // expr1DataGridViewTextBoxColumn
            // 
            this.expr1DataGridViewTextBoxColumn.DataPropertyName = "Expr1";
            this.expr1DataGridViewTextBoxColumn.HeaderText = "Выбрала данный вариант";
            this.expr1DataGridViewTextBoxColumn.Name = "expr1DataGridViewTextBoxColumn";
            // 
            // numABindingSource
            // 
            this.numABindingSource.DataMember = "numA";
            this.numABindingSource.DataSource = this.g464_Iln_AlaDataSet7;
            // 
            // g464_Iln_AlaDataSet7
            // 
            this.g464_Iln_AlaDataSet7.DataSetName = "g464_Iln_AlaDataSet7";
            this.g464_Iln_AlaDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 62;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(323, 38);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(41, 13);
            this.label52.TabIndex = 61;
            this.label52.Text = "label52";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(104, 38);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(213, 13);
            this.label51.TabIndex = 60;
            this.label51.Text = "Всего зарегестрировалось на марафон:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(207, 225);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 13);
            this.label14.TabIndex = 59;
            this.label14.Text = "Состав комплекта";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(206, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 24);
            this.label1.TabIndex = 58;
            this.label1.Text = "Инвентарь";
            // 
            // numATableAdapter
            // 
            this.numATableAdapter.ClearBeforeFill = true;
            // 
            // sumTableAdapter
            // 
            this.sumTableAdapter.ClearBeforeFill = true;
            // 
            // neobxTableAdapter
            // 
            this.neobxTableAdapter.ClearBeforeFill = true;
            // 
            // Form19
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 495);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label1);
            this.Name = "Form19";
            this.Text = "Form19";
            this.Load += new System.EventHandler(this.Form19_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.neobxBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_Iln_AlaDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_Iln_AlaDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numABindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.g464_Iln_AlaDataSet7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label1;
        private g464_Iln_AlaDataSet7 g464_Iln_AlaDataSet7;
        private System.Windows.Forms.BindingSource numABindingSource;
        private g464_Iln_AlaDataSet7TableAdapters.numATableAdapter numATableAdapter;
        private g464_Iln_AlaDataSet8 g464_Iln_AlaDataSet8;
        private System.Windows.Forms.BindingSource sumBindingSource;
        private g464_Iln_AlaDataSet8TableAdapters.sumTableAdapter sumTableAdapter;
        private g464_Iln_AlaDataSet9 g464_Iln_AlaDataSet9;
        private System.Windows.Forms.BindingSource neobxBindingSource;
        private g464_Iln_AlaDataSet9TableAdapters.NeobxTableAdapter neobxTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn aDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn neobhodimoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn expr1DataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn raceKitOptionIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn expr1DataGridViewTextBoxColumn;
    }
}