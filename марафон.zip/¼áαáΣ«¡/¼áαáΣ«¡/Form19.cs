﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace марафон
{
    public partial class Form19 : Form
    {
        public Form19()
        {
            InitializeComponent();
        }

        private void Form19_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "g464_Iln_AlaDataSet9.Neobx". При необходимости она может быть перемещена или удалена.
            this.neobxTableAdapter.Fill(this.g464_Iln_AlaDataSet9.Neobx);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "g464_Iln_AlaDataSet8.sum". При необходимости она может быть перемещена или удалена.
            this.sumTableAdapter.Fill(this.g464_Iln_AlaDataSet8.sum);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "g464_Iln_AlaDataSet7.numA". При необходимости она может быть перемещена или удалена.
            this.numATableAdapter.Fill(this.g464_Iln_AlaDataSet7.numA);
            string A;

            //  string conn = "Data Source=127.0.0.1;Initial Catalog=g464_Iln_Ala;User ID=student;Password=student";
            string conn = "Data Source=WIN-D0D1L0QJR2B;Initial Catalog=g464_Iln_Ala;Integrated Security=True";
            SqlConnection con = new SqlConnection(conn);

            con.Open();
            string str = "SELECT COUNT(*) AS Необходимо FROM dbo.Registration";

            SqlCommand cmd2 = new SqlCommand(str, con);
            SqlDataReader rdr = cmd2.ExecuteReader();
            while (rdr.Read() == true)
            {
                A = Convert.ToString(rdr.GetInt32(0));
                label52.Text = A;
            }
            rdr.Close();

            con.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form10 yyy = new Form10();
            yyy.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form24 yyy = new Form24();
            yyy.Show();
        }
    }
}
