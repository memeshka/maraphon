﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace марафон
{
    public partial class Form20 : Form
    {
        public Form20()
        {
            InitializeComponent();
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox11.Image;
            label11.Text = "Этот автобус пролетает со скоростью 10км ";
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox10.Image;
            label11.Text = "Эти тапки пролетают со скоростью 25км ";
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox9.Image;
            label11.Text = "Это поле пролетает со скоростью 36км ";
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox8.Image;
            label11.Text = "Этот Рональдиньо пролетает со скоростью 45км ";
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox7.Image;
            label11.Text = "Этот Самолет пролетает со скоростью 56км ";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox1.Image;
            label11.Text = "Эта формула пролетает со скоростью 190км ";
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox2.Image;
            label11.Text = "Этот червяк пролетает со скоростью 1км ";
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox4.Image;
            label11.Text = "Этот Ленивец пролетает со скоростью 2км ";
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox5.Image;
            label11.Text = "Эта капибара пролетает со скоростью 22км ";
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox6.Image;
            label11.Text = "Этот ягуар пролетает со скоростью 87км ";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 yyy = new Form4();
            yyy.Show();
        }
    }
}
