﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace марафон
{
    public partial class Form21 : Form
    {
        public Form21()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form10 yyy = new Form10();
            yyy.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form22 yyy = new Form22();
            yyy.Show();
        }

        private void Form21_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "g464_Iln_AlaDataSet6.Volunteer". При необходимости она может быть перемещена или удалена.
            this.volunteerTableAdapter.Fill(this.g464_Iln_AlaDataSet6.Volunteer);


            

            //  string conn = "Data Source=127.0.0.1;Initial Catalog=g464_Iln_Ala;User ID=student;Password=student";
            string con_str = "Data Source=WIN-D0D1L0QJR2B;Initial Catalog=g464_Iln_Ala;Integrated Security=True";
            using (SqlConnection connection = new SqlConnection(con_str))
            {
                    SqlCommand command = new SqlCommand("select count(VolunteerId) as count from Volunteer", connection);
                    connection.Open();
                    label6.Text = command.ExecuteScalar().ToString();
                    connection.Close();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.Sort(dataGridView1.Columns[comboBox1.Text], ListSortDirection.Ascending);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Update();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 yyy = new Form1();
            yyy.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan t = Program.start - DateTime.Now;
            label7.Text = t.Days.ToString() + " days, " +
                t.Hours.ToString() + " hours, " +
                t.Minutes.ToString() + " minutes";
        }
    }
}
