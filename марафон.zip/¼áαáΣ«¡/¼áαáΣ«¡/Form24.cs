﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace марафон
{
    public partial class Form24 : Form
    {
        public Form24()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //  string conn = "Data Source=127.0.0.1;Initial Catalog=g464_Iln_Ala;User ID=student;Password=student";
            string conn = "Data Source=WIN-D0D1L0QJR2B;Initial Catalog=g464_Iln_Ala;Integrated Security=True";
            SqlConnection con = new SqlConnection(conn);
            con.Open();
            string str = "UPDATE[Inventory] SET [Номер бегуна] = [Номер бегуна] + '" + textBox1.Text + "',[RFID браслет]=[RFID браслет]+ '" + textBox2.Text + "',[Бейсболка]=[Бейсболка]+ '" + textBox3.Text + "',[Бутылка воды]=[Бутылка воды]+ '" + textBox4.Text + "',[Футболка]=[Футболка]+ '" + textBox5.Text + "',[Сувенирный буклет]=[Сувенирный буклет]+ '" + textBox6.Text + "' WHERE([Инвентарь]= 'Ostatok')";
            SqlCommand cmd2 = new SqlCommand(str, con);
            cmd2.ExecuteNonQuery();
            con.Close();
            this.Close();
            Form19 open = new Form19();
            open.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form19 open = new Form19();
            open.Show();
        }
    }
}
