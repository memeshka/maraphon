﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace марафон
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 yyy = new Form1();
            yyy.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 yyy = new Form1();
            yyy.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            Form14 yyy = new Form14();
            yyy.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            Form11 yyy = new Form11();
            yyy.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            Form17 yyy = new Form17();
            yyy.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan t = Program.start - DateTime.Now;
            label2.Text = t.Days.ToString() + " days, " +
                t.Hours.ToString() + " hours, " +
                t.Minutes.ToString() + " minutes";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
            Form18 yyy = new Form18();
            yyy.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
            Form23 yyy = new Form23();
            yyy.Show();
        }
    }
}
